declare module 'google-maps-react';
